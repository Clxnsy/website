# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Stack
delegated: Vite + React, chosen for its fast developer experience, component-driven architecture, and excellent support for modern, high-performance web experiences.

## Users
Hiring managers, recruiters, and engineering leaders who are evaluating the candidate to decide if they want to hire them.

## Product Purpose
To present a digital resume and portfolio that convinces a company to hire the candidate. Success means securing an interview by leaving a strong, memorable impression.

## Positioning
A noticeably faster and more modern experience than typical competitor portfolios, demonstrating high taste and technical competence.

## Operating Context
Scanned quickly by evaluators in web browsers (both desktop and mobile), often compared back-to-back with other candidate profiles.

## Capabilities and Constraints
No existing technical constraints. The experience must be fully responsive, highly performant, and distraction-free.

## Brand Commitments
No pre-existing constraints; open to a fresh, bold visual direction.

## Evidence on Hand
No specific content provided yet. Future design and implementation must accommodate real career history and project assets without fabricating evidence.

## Product Principles
1. **Show, don't just tell:** Use the interface itself as proof of modern technical and design skill.
2. **Speed as a feature:** Deliver an instantly responsive and snappy experience.
3. **Scanability first:** Ensure that evaluators can parse the most critical information in seconds.

## Accessibility & Inclusion
Must follow standard web accessibility practices (WCAG guidelines) so all visitors can navigate the portfolio smoothly.
