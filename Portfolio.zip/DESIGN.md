---
name: Clansy Barcklow Portfolio
description: A high-energy technical portfolio featuring electric blue and neon purple with dynamic background animations.
colors:
  canvas: "#050814"
  canvas-secondary: "#0a1026"
  accent: "#b026ff"
  accent-hover: "#c856ff"
  accent-alt: "#00d2ff"
  text-main: "#ffffff"
  text-muted: "rgba(255, 255, 255, 0.6)"
  border: "rgba(255, 255, 255, 0.1)"
typography:
  display:
    fontFamily: '"Integral CF Bold", "Integral CF Extra Bold", sans-serif'
    fontWeight: 700
  body:
    fontFamily: '"Titillium Web", sans-serif'
    fontWeight: 400
  mono:
    fontFamily: '"Fragment Mono", monospace'
    fontWeight: 400
rounded:
  sm: "4px"
  md: "8px"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "32px"
  xl: "64px"
components:
  card:
    backgroundColor: "rgba(10, 16, 38, 0.6)"
    border: "1px solid rgba(255, 255, 255, 0.05)"
    backdropFilter: "blur(12px)"
    rounded: "{rounded.md}"
    padding: "{spacing.lg}"
---

# Design System: Clansy Barcklow Portfolio (Dynamic Purple/Blue)

## Overview

**Creative North Star: "Dynamic Cybernetic Infrastructure"**

This system embraces a bold, modern, and sleek aesthetic. It shifts away from aggressive red to a cooler, more dynamic electric blue and neon purple palette. The background is brought to life with slowly orbiting, animated ambient glows.

**Key Characteristics:**
- Deep space canvas (`#050814`).
- Neon purple (`#b026ff`) and electric blue (`#00d2ff`) accents.
- Massive, uppercase, tightly-tracked display typography (Integral CF).
- Animated, non-static glassmorphic layers and floating ambient orbs.

## Colors

### Primary
- **Purple Accent** (`#b026ff`): Primary actions, highlights, brand color.
- **Purple Accent Hover** (`#c856ff`): Lighter state for interaction.
- **Electric Blue** (`#00d2ff`): Secondary highlights and gradient pairs.

### Neutral
- **Canvas** (`#050814`): Deepest background layer.
- **Canvas Secondary** (`#0a1026`): Elevated surfaces, cards.
- **Text Main** (`#ffffff`): High contrast white for readability.
- **Text Muted** (`rgba(255, 255, 255, 0.6)`): Subtitles, metadata, timestamps.
- **Border** (`rgba(255, 255, 255, 0.1)`): Glass borders.

## Typography

**Display Font:** Integral CF (Bold, Extra Bold)
**Body Font:** Titillium Web (400, 700)
**Mono Font:** Fragment Mono (for technical metadata)

**Character:** Very loud and confident display headings. Crisp and clean body text. 

## Components

### Glass Cards
- **Border:** `1px solid rgba(255, 255, 255, 0.05)`.
- **Background:** `rgba(10, 16, 38, 0.6)`.
- **Backdrop-filter:** `blur(12px)`.
- **Hover:** Border glows purple or opacity shifts slightly. Subtle translation upwards.

### Animated Background
- Instead of a static background, multiple large radial gradients (blue and purple) orbit slowly across the canvas, giving it life and depth without distracting from the content.
