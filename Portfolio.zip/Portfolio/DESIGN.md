---
name: Clansy Barcklow Portfolio
description: An editorial systems dossier built around clear technical delivery and evidence.
colors:
  ink: "#08091a"
  ink-secondary: "#10122a"
  ink-elevated: "#17182d"
  ink-mid: "#33364a"
  ink-muted: "#55586c"
  paper: "#f1f2ed"
  paper-soft: "#d6d7e2"
  violet: "#7657ff"
  violet-deep: "#5c3df2"
  mint: "#b8ffda"
typography:
  sans:
    fontFamily: '"Manrope", "Segoe UI", sans-serif'
    role: "Primary display, interface, and body voice"
  accent:
    fontFamily: '"Bodoni Moda", Georgia, serif'
    role: "Selective italic contrast in the hero and editorial notes"
rounded:
  surface: "14px"
  control: "999px"
---

# Design System: Editorial Systems Dossier

## Creative direction

The portfolio presents Clansy as a calm, systems-minded operator rather than using a conventional stack of resume cards. The page behaves like a living delivery record: strong typographic statements, a real editorial portrait, crisp dividers, factual proof, and one diagrammatic project case study.

The established blue-purple identity remains, but decorative glass and generic neon effects have been replaced by large ultraviolet fields, ink-blue surfaces, and electric mint signals. The result should feel technical without relying on terminal motifs or monospace styling.

## Color strategy

- Ink (`#08091a`) is the primary canvas and trust-building base.
- Paper (`#f1f2ed`) creates high-contrast reading sections and avoids pure white glare.
- Deep violet (`#5c3df2`) owns the hero system panel and featured project.
- Mint (`#b8ffda`) marks availability, emphasis, validation, and the closing contact surface.
- Muted copy is hue-aware; gray text is never placed on violet or mint without contrast checking.
- Paper opacity ramps at 7%, 18%, 22%, 30%, and 72% support rules, orbit geometry, and secondary copy on saturated fields.

## Typography

- Manrope carries almost all headings, navigation, labels, and body copy.
- Bodoni Moda italic appears sparingly as a human counterpoint inside technical compositions.
- Display text uses tight but bounded tracking and never exceeds 6rem.
- Body copy stays within roughly 65 characters per line for easy scanning.

## Composition

- The desktop hero is a 2:1 split: value proposition on ink, full-bleed portrait and verified education details on violet.
- The fixed header owns an opaque ink surface and uses the full name as its wordmark; no monogram or template-style label sits over the portrait.
- Proof metrics form one continuous ruled band, not individual cards.
- A looping logo rail identifies the actual tools in the supplied resume; it pauses when offscreen, when hovered, or when the page is hidden.
- Profile content switches to a paper field for reading comfort.
- Experience is structured as an editorial index with dates, narrative, and restrained letter markers.
- The featured project is the highest-expression block and includes a real scope map.
- Mobile collapses every split cleanly and uses an accessible full-width navigation panel.

## Interaction and motion

- The portrait is intentionally static and contained in a fixed square frame; it never follows the pointer or shifts on hover.
- Experience rows disclose their relationship through a shared background sweep, active navigation tracks the current section, and primary actions use bounded magnetic feedback.
- Reduced-motion preferences disable non-essential animation.
- All interactive elements expose visible keyboard focus.
- The mobile menu locks page scrolling while open and closes on navigation.
- The mobile menu also closes with Escape and restores focus to its trigger.

## Component rules

- Use 14px radii only on significant contained surfaces and rectangular actions.
- Pills are reserved for navigation actions and compact project tags.
- Use either a border or a soft offset shadow for depth, never both on the same surface.
- Preserve generous section spacing and the ruled horizontal rhythm when extending the page.
- Do not reintroduce glass cards, gradient text, generic skill badges, or decorative grid backgrounds.
